import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView,Image} from 'react-native';
import { styles } from './styles';
 
export default function App(){
  const [random, setRandom] = useState()
  const [resultado, setResultado] = useState()

  function Img(){
    let img = 'https://media-cldnry.s-nbcnews.com/image/upload/t_social_share_1200x630_center,f_auto,q_auto:best/newscms/2021_05/1669654/steve-harvey-feud-mc-main-210203.jpg';
    return(
      <Image 
      source={{uri:img}}
      style={{width: 350, height:250, }}
      />
    )
  }

  function calcular(){
      setRandom(Math.floor(Math.random() * 10))
      setResultado(random)    
  }
 
  return(
    <ScrollView>
      <View style={styles.container}>

        <Text style={styles.titulo}>Jogo com um número aleatório</Text>
      <Img/>
      <Text style={styles.texto}>Pense em um número de 0 a 10</Text>
      <Text style={styles.resultado}> {resultado} </Text>
      
      <Pressable style={styles.pressable}  onPress={calcular}>
    <Text style={styles.texto}> Chute </Text>
    </Pressable>

      </View>
    </ScrollView>
  );
}